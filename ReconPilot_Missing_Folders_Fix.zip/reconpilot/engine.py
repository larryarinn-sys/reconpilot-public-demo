from __future__ import annotations

from itertools import product
import pandas as pd


PAIR_COLUMNS = [
    "Bank row", "Books row", "Bank date", "Books date", "Bank description", "Books description",
    "Bank reference", "Books reference", "Bank amount", "Books amount", "Amount difference",
    "Date difference (days)", "Result",
]


def _date_diff(a, b) -> int:
    return abs((pd.Timestamp(a) - pd.Timestamp(b)).days)


def _pair_record(bank_row, books_row, result: str) -> dict:
    amount_diff = round(abs(float(bank_row["Amount"]) - float(books_row["Amount"])), 2)
    date_diff = _date_diff(bank_row["Date"], books_row["Date"])
    return {
        "Bank row": int(bank_row["Source row"]),
        "Books row": int(books_row["Source row"]),
        "Bank date": bank_row["Date"].date(),
        "Books date": books_row["Date"].date(),
        "Bank description": bank_row["Description"],
        "Books description": books_row["Description"],
        "Bank reference": bank_row["Reference"],
        "Books reference": books_row["Reference"],
        "Bank amount": float(bank_row["Amount"]),
        "Books amount": float(books_row["Amount"]),
        "Amount difference": amount_diff,
        "Date difference (days)": date_diff,
        "Result": result,
    }


def _to_frame(rows: list[dict]) -> pd.DataFrame:
    return pd.DataFrame(rows, columns=PAIR_COLUMNS)


def reconcile(
    bank: pd.DataFrame,
    books: pd.DataFrame,
    amount_tolerance: float = 0.01,
    date_tolerance_days: int = 3,
) -> dict[str, pd.DataFrame]:
    """One-to-one transaction matching with conservative auto-confirmation.

    Auto-confirmation requires a unique nonblank reference on both sides and
    amount/date differences inside tolerances. All weaker matches go to review.
    """
    bank = bank.copy().reset_index(drop=True)
    books = books.copy().reset_index(drop=True)
    used_bank: set[int] = set()
    used_books: set[int] = set()
    matched_rows: list[dict] = []
    review_rows: list[dict] = []

    # Pass 1: pair transactions with the same normalised reference.
    bank_counts = bank[bank["_reference_key"] != ""]["_reference_key"].value_counts().to_dict()
    books_counts = books[books["_reference_key"] != ""]["_reference_key"].value_counts().to_dict()
    common_refs = set(bank_counts) & set(books_counts)

    for ref in sorted(common_refs):
        bgroup = bank[(bank["_reference_key"] == ref) & (~bank["_id"].isin(used_bank))]
        cgroup = books[(books["_reference_key"] == ref) & (~books["_id"].isin(used_books))]
        candidates = []
        for (_, br), (_, cr) in product(bgroup.iterrows(), cgroup.iterrows()):
            candidates.append((
                abs(float(br["Amount"]) - float(cr["Amount"])),
                _date_diff(br["Date"], cr["Date"]),
                int(br["_id"]), int(cr["_id"]), br, cr,
            ))
        candidates.sort(key=lambda x: (x[0], x[1]))
        duplicate_ref = bank_counts.get(ref, 0) > 1 or books_counts.get(ref, 0) > 1
        for amount_diff, date_diff, bid, cid, br, cr in candidates:
            if bid in used_bank or cid in used_books:
                continue
            used_bank.add(bid)
            used_books.add(cid)
            if duplicate_ref:
                status = "Review - duplicate reference"
                review_rows.append(_pair_record(br, cr, status))
            elif amount_diff <= amount_tolerance and date_diff <= date_tolerance_days:
                matched_rows.append(_pair_record(br, cr, "Confirmed - unique reference"))
            elif amount_diff > amount_tolerance:
                review_rows.append(_pair_record(br, cr, "Review - amount mismatch"))
            else:
                review_rows.append(_pair_record(br, cr, "Review - date difference"))

    # Pass 2: suggest amount + date pairs when reference did not produce a match.
    remaining_bank = bank[~bank["_id"].isin(used_bank)]
    remaining_books = books[~books["_id"].isin(used_books)]
    candidates = []
    bank_candidate_count: dict[int, int] = {}
    books_candidate_count: dict[int, int] = {}
    for (_, br), (_, cr) in product(remaining_bank.iterrows(), remaining_books.iterrows()):
        amount_diff = abs(float(br["Amount"]) - float(cr["Amount"]))
        date_diff = _date_diff(br["Date"], cr["Date"])
        if amount_diff <= amount_tolerance and date_diff <= date_tolerance_days:
            bid, cid = int(br["_id"]), int(cr["_id"])
            bank_candidate_count[bid] = bank_candidate_count.get(bid, 0) + 1
            books_candidate_count[cid] = books_candidate_count.get(cid, 0) + 1
            candidates.append((amount_diff, date_diff, bid, cid, br, cr))
    candidates.sort(key=lambda x: (x[0], x[1]))
    for amount_diff, date_diff, bid, cid, br, cr in candidates:
        if bid in used_bank or cid in used_books:
            continue
        used_bank.add(bid)
        used_books.add(cid)
        unique = bank_candidate_count.get(bid) == 1 and books_candidate_count.get(cid) == 1
        status = "Suggested - amount and date only" if unique else "Review - ambiguous amount/date candidates"
        review_rows.append(_pair_record(br, cr, status))

    unmatched_bank = bank[~bank["_id"].isin(used_bank)].copy()
    unmatched_books = books[~books["_id"].isin(used_books)].copy()
    unmatched_bank["Reason"] = "No candidate found within the selected amount/date tolerances"
    unmatched_books["Reason"] = "No candidate found within the selected amount/date tolerances"

    display_cols = ["Source row", "Date", "Description", "Reference", "Amount", "Reason"]
    return {
        "matched": _to_frame(matched_rows),
        "review": _to_frame(review_rows),
        "unmatched_bank": unmatched_bank[display_cols].reset_index(drop=True),
        "unmatched_books": unmatched_books[display_cols].reset_index(drop=True),
    }
