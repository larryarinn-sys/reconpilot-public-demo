from __future__ import annotations

from io import BytesIO
from copy import copy
import pandas as pd

from reconpilot.review import empty_decision_log, latest_decision_counts


def build_excel_report(
    result: dict[str, pd.DataFrame],
    meta: dict,
    decision_log: pd.DataFrame | None = None,
) -> bytes:
    output = BytesIO()
    decision_log = empty_decision_log() if decision_log is None else decision_log.copy()
    counts = latest_decision_counts(decision_log)
    summary = pd.DataFrame([
        ["Report", "ReconPilot reconciliation"],
        ["Prototype version", "0.2.0"],
        ["Bank rows", meta.get("bank_rows", "")],
        ["Books rows", meta.get("books_rows", "")],
        ["Amount tolerance", meta.get("amount_tolerance", "")],
        ["Date tolerance (days)", meta.get("date_tolerance", "")],
        ["Rule-confirmed matches", len(result["matched"])],
        ["Needs review", len(result["review"])],
        ["Manually approved review pairs", counts["Approve pair"]],
        ["Manually rejected review pairs", counts["Reject pair"]],
        ["Unmatched bank", len(result["unmatched_bank"])],
        ["Unmatched books", len(result["unmatched_books"])],
        ["Note", "Rule-confirmed matches and human decisions are separate. Review this working paper; it is not an audit opinion."],
    ], columns=["Metric", "Value"])
    with pd.ExcelWriter(output, engine="openpyxl", date_format="yyyy-mm-dd", datetime_format="yyyy-mm-dd") as writer:
        summary.to_excel(writer, sheet_name="Summary", index=False)
        result["matched"].to_excel(writer, sheet_name="Rule Matches", index=False)
        result["review"].to_excel(writer, sheet_name="Review Candidates", index=False)
        result["unmatched_bank"].to_excel(writer, sheet_name="Unmatched Bank", index=False)
        result["unmatched_books"].to_excel(writer, sheet_name="Unmatched Books", index=False)
        decision_log.to_excel(writer, sheet_name="Decision Log", index=False)
        for ws in writer.book.worksheets:
            ws.freeze_panes = "A2"
            if ws.max_row > 1 and ws.max_column > 0:
                ws.auto_filter.ref = ws.dimensions
            for col_cells in ws.columns:
                max_len = max((len(str(cell.value)) if cell.value is not None else 0) for cell in col_cells)
                ws.column_dimensions[col_cells[0].column_letter].width = min(max(max_len + 2, 12), 42)
            from openpyxl.styles import PatternFill
            for cell in ws[1]:
                header_font = copy(cell.font)
                header_font.bold = True
                header_font.color = "FFFFFF"
                cell.font = header_font
                cell.fill = PatternFill("solid", fgColor="403A70")
    return output.getvalue()
