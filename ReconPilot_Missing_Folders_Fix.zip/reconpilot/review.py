from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo

import pandas as pd

DECISION_OPTIONS = ["Pending", "Approve pair", "Reject pair"]
EVENT_COLUMNS = [
    "Review ID", "Bank row", "Books row", "Previous decision", "New decision",
    "Reviewer note", "Reviewed at",
]


def empty_decision_log() -> pd.DataFrame:
    return pd.DataFrame(columns=EVENT_COLUMNS)


def create_review_workspace(
    review_candidates: pd.DataFrame,
    decision_log: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Create the editable review table and restore each pair's latest decision."""
    workspace = review_candidates.copy().reset_index(drop=True)
    workspace.insert(0, "Review ID", [f"RP-{i:04d}" for i in range(1, len(workspace) + 1)])
    workspace["Decision"] = "Pending"
    workspace["Reviewer note"] = ""
    workspace["Last reviewed"] = ""

    if decision_log is not None and not decision_log.empty:
        latest = decision_log.drop_duplicates("Review ID", keep="last").set_index("Review ID")
        for index, row in workspace.iterrows():
            review_id = row["Review ID"]
            if review_id in latest.index:
                event = latest.loc[review_id]
                workspace.at[index, "Decision"] = event["New decision"]
                workspace.at[index, "Reviewer note"] = event["Reviewer note"]
                workspace.at[index, "Last reviewed"] = event["Reviewed at"]
    return workspace


def record_review_changes(
    edited_workspace: pd.DataFrame,
    decision_log: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Append only changed decisions, preserving a simple session-level event history."""
    existing = empty_decision_log() if decision_log is None else decision_log.copy()
    if existing.empty:
        existing = empty_decision_log()
    else:
        existing = existing.reindex(columns=EVENT_COLUMNS)

    latest = {}
    if not existing.empty:
        for _, event in existing.drop_duplicates("Review ID", keep="last").iterrows():
            latest[event["Review ID"]] = event.to_dict()

    new_events = []
    for _, row in edited_workspace.iterrows():
        review_id = str(row["Review ID"])
        decision = str(row.get("Decision", "Pending"))
        note = str(row.get("Reviewer note", "") or "").strip()
        if decision not in DECISION_OPTIONS:
            raise ValueError(f"Invalid decision for {review_id}: {decision}")

        previous = latest.get(review_id, {})
        previous_decision = previous.get("New decision", "Pending")
        previous_note = previous.get("Reviewer note", "")
        if decision == previous_decision and note == previous_note:
            continue

        new_events.append({
            "Review ID": review_id,
            "Bank row": row.get("Bank row", ""),
            "Books row": row.get("Books row", ""),
            "Previous decision": previous_decision,
            "New decision": decision,
            "Reviewer note": note,
            "Reviewed at": datetime.now(ZoneInfo("Asia/Kolkata")).isoformat(timespec="seconds"),
        })

    if new_events:
        existing = pd.concat([existing, pd.DataFrame(new_events, columns=EVENT_COLUMNS)], ignore_index=True)
    return existing.reindex(columns=EVENT_COLUMNS)


def latest_decision_counts(decision_log: pd.DataFrame | None = None) -> dict[str, int]:
    if decision_log is None or decision_log.empty:
        return {choice: 0 for choice in DECISION_OPTIONS}
    latest = decision_log.drop_duplicates("Review ID", keep="last")
    counts = latest["New decision"].value_counts().to_dict()
    return {choice: int(counts.get(choice, 0)) for choice in DECISION_OPTIONS}
