from __future__ import annotations

import re
from typing import Any

import pandas as pd


def read_uploaded_file(uploaded_file) -> pd.DataFrame:
    """Read the first worksheet of an uploaded Excel file or a CSV file."""
    name = getattr(uploaded_file, "name", "").lower()
    uploaded_file.seek(0)
    if name.endswith(".csv"):
        # utf-8-sig handles common Excel-exported CSV files.
        try:
            return pd.read_csv(uploaded_file, encoding="utf-8-sig")
        except UnicodeDecodeError:
            uploaded_file.seek(0)
            return pd.read_csv(uploaded_file, encoding="latin-1")
    if name.endswith((".xlsx", ".xls")):
        return pd.read_excel(uploaded_file, sheet_name=0)
    raise ValueError("Unsupported file. Please upload CSV, XLSX, or XLS.")


def _parse_number(value: Any) -> float:
    if pd.isna(value):
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not text or text in {"-", "—", "–"}:
        return 0.0
    negative = text.startswith("(") and text.endswith(")")
    text = text.replace(",", "")
    text = re.sub(r"[^0-9.\-]", "", text)
    if text in {"", "-", ".", "-."}:
        return 0.0
    number = float(text)
    return -abs(number) if negative else number


def _clean_reference(value: Any) -> str:
    if pd.isna(value):
        return ""
    return re.sub(r"[^A-Z0-9]", "", str(value).upper().strip())


def validate_mapping(mapping: dict, columns, label: str) -> None:
    if not mapping.get("date_col"):
        raise ValueError(f"{label}: select a date column.")
    if mapping.get("amount_col"):
        return
    if not mapping.get("debit_col") and not mapping.get("credit_col"):
        raise ValueError(f"{label}: select an amount column or at least one debit/credit column.")
    if mapping.get("debit_col") and mapping.get("debit_col") not in columns:
        raise ValueError(f"{label}: debit column was not found.")
    if mapping.get("credit_col") and mapping.get("credit_col") not in columns:
        raise ValueError(f"{label}: credit column was not found.")


def standardize_transactions(df: pd.DataFrame, mapping: dict, source: str) -> pd.DataFrame:
    """Convert a source file into ReconPilot's standard signed transaction format.

    Positive amount = money in / credit. Negative amount = money out / debit.
    """
    validate_mapping(mapping, df.columns, source)
    out = pd.DataFrame(index=df.index)
    out["Source row"] = [int(i) + 2 if isinstance(i, int) else pos + 2 for pos, i in enumerate(df.index)]
    out["Date"] = pd.to_datetime(
        df[mapping["date_col"]], errors="coerce", dayfirst=bool(mapping.get("dayfirst", True))
    ).dt.normalize()
    if mapping.get("amount_col"):
        out["Amount"] = df[mapping["amount_col"]].map(_parse_number)
    else:
        debit = df[mapping["debit_col"]].map(_parse_number) if mapping.get("debit_col") else 0.0
        credit = df[mapping["credit_col"]].map(_parse_number) if mapping.get("credit_col") else 0.0
        out["Amount"] = credit - debit
    if mapping.get("reference_col"):
        out["Reference"] = df[mapping["reference_col"]].fillna("").astype(str).str.strip()
    else:
        out["Reference"] = ""
    if mapping.get("description_col"):
        out["Description"] = df[mapping["description_col"]].fillna("").astype(str).str.strip()
    else:
        out["Description"] = ""
    out["_reference_key"] = out["Reference"].map(_clean_reference)
    out["Source"] = source

    invalid_dates = out["Date"].isna().sum()
    if invalid_dates:
        raise ValueError(
            f"{source}: {invalid_dates} row(s) have blank or unrecognised dates. Fix the date column and upload again."
        )
    out["Amount"] = out["Amount"].astype(float).round(2)
    out = out.reset_index(drop=True)
    out["_id"] = range(len(out))
    return out[["_id", "Source row", "Date", "Description", "Reference", "_reference_key", "Amount", "Source"]]
